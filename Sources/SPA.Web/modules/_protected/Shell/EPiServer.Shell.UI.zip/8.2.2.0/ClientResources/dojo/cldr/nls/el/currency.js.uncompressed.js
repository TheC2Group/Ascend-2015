define(
"dojo/cldr/nls/el/currency", //begin v1.x content
{
	"HKD_displayName": "Δολάριο Χονγκ Κονγκ",
	"CHF_displayName": "Φράγκο Ελβετίας",
	"CAD_displayName": "Δολάριο Καναδά",
	"CNY_displayName": "Γιουάν Ρενμίμπι Κίνας",
	"USD_symbol": "$",
	"AUD_displayName": "Δολάριο Αυστραλίας",
	"JPY_displayName": "Γιεν Ιαπωνίας",
	"USD_displayName": "Δολάριο ΗΠΑ",
	"GBP_displayName": "Λίρα Στερλίνα Βρετανίας",
	"EUR_displayName": "Ευρώ"
}
//end v1.x content
);